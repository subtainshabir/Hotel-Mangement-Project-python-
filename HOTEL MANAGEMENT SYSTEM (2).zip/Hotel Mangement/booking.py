from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
from tkinter import ttk
from time import strftime
from datetime import datetime

class book_det:
    def __init__(self, root):
        self.root=root
        self.root.title("Booking")
        self.root.geometry("1030x465+248+178")

        # *****************Title*******************
        title = Label(self.root, text="BOOKING DETAILS", bg="black", fg="Gold", font="timesnewroman 18  bold")
        title.place(x=0, y=0, width=1020, height=40)


        #**************************VARIABLES********************
        self.var_contact = StringVar()
        self.var_checkin= StringVar()
        self.var_checkout = StringVar()
        self.var_roomtype= StringVar()
        self.var_roomavail = StringVar()
        self.var_meal= StringVar()
        self.var_days= StringVar()
        self.var_no_days=StringVar()
        self.var_tax = StringVar()
        self.var_total= StringVar()


        # *****************logo*******************
        logo = Image.open("logo.png")
        resized_logo = logo.resize((160, 40), Image.ANTIALIAS)
        self.logo1 = ImageTk.PhotoImage(resized_logo)
        label_1 = Label(root, image=self.logo1)
        label_1.place(x=0, y=0, width=160, height=40)

        #*****************label frame*********************
        label_frame=LabelFrame(self.root,text="Booking Details",bd=3,relief=SUNKEN,font="timesnewroman 14  bold",cursor="hand2")
        label_frame.place(x=10,y=41,width=400,height=400)

        #*****************Label and Entries***************
        #contact
        cus_ph=Label(label_frame,text="Customer Phone No",fg="black",font="timesnewroman 12 bold",padx=2,pady=4)
        cus_ph.grid(row=0,column=0)
        cus_entry=ttk.Entry(label_frame,width=14,textvariable=self.var_contact,font="timesnewroman 12")
        cus_entry.grid(row=0,column=1,sticky=W)
        
        fetch_button = Button(label_frame, text="fetch", command=self.fetch_contact,font="timesnewroman 8", bg="black",
                             fg="gold", width=10)
        fetch_button.place(x=300,y=0)
        #Check_in
        check_in = Label(label_frame, text="Check in date", font="timesnewroman 12 bold", padx=2, pady=4)
        check_in.grid(row=1, column=0, sticky=W)
        check_en = ttk.Entry(label_frame, width=22,textvariable=self.var_checkin, font="timesnewroman 12")
        check_en.grid(row=1, column=1,sticky=W)
        #check0ut
        check_out = Label(label_frame, text="Check out date", font="timesnewroman 12 bold", padx=2, pady=4)
        check_out.grid(row=2, column=0, sticky=W)
        check_ot = ttk.Entry(label_frame, width=22, textvariable=self.var_checkout,font="timesnewroman 12")
        check_ot.grid(row=2, column=1, sticky=W)
        #Room type
        Room_type =Label(label_frame, text="Room Type", font="timesnewroman 12 bold", padx=2, pady=4)
        Room_type.grid(row=3, column=0, sticky=W)
        roomtype_combo = ttk.Combobox(label_frame, text="SELECT", textvariable=self.var_roomtype,
                                         font="timesnewroman 12",
                                         width=20, state='readonly')
        roomtype_combo["values"] = ("Single Room", "Double Room", "Triple Room")
        roomtype_combo.current(0)
        roomtype_combo.grid(row=3, column=1)
        #room Availability
        room_avail = Label(label_frame, text="Room Availability", font="timesnewroman 12 bold", padx=2, pady=4)
        room_avail.grid(row=4, column=0, sticky=W)
        # rom_av = ttk.Entry(label_frame, width=22, textvariable=self.var_roomavail,font="timesnewroman 12")
        # rom_av.grid(row=4, column=1, sticky=W)
        conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT room_no FROM room_details")
        rows=my_cursor.fetchall()
        roomavail_combo = ttk.Combobox(label_frame, text="SELECT", textvariable=self.var_roomavail,
                                       font="timesnewroman 12",width=20, state='readonly')
        roomavail_combo["values"] = rows
        roomavail_combo.current(0)
        roomavail_combo.grid(row=4, column=1)
        
        #meal
        meal = Label(label_frame, text="Meal", font="timesnewroman 12 bold", padx=2, pady=4)
        meal.grid(row=5, column=0, sticky=W)
        meal_combo = ttk.Combobox(label_frame, text="SELECT", textvariable=self.var_meal,
                                         font="timesnewroman 12",
                                         width=20, state='readonly')
        meal_combo["values"] = ("Breakfast", "Lunch", "Dinner")
        meal_combo.current(0)
        meal_combo.grid(row=5, column=1, sticky=W)
        #Lunch
        no_day = Label(label_frame, text="No of days", font="timesnewroman 12 bold", padx=2, pady=4)
        no_day.grid(row=6, column=0, sticky=W)
        Num_days = ttk.Entry(label_frame, width=22, textvariable=self.var_no_days,font="timesnewroman 12")
        Num_days.grid(row=6, column=1, sticky=W)
        #tax
        tax_l = Label(label_frame, text="Paid Tax", font="timesnewroman 12 bold", padx=2, pady=4)
        tax_l.grid(row=7, column=0, sticky=W)
        tax_e = ttk.Entry(label_frame, width=22,textvariable=self.var_tax,font="timesnewroman 12")
        tax_e.grid(row=7, column=1)
        #total
        a_total = Label(label_frame, text="Actual Total", font="timesnewroman 12 bold", padx=2, pady=4)
        a_total.grid(row=8, column=0, sticky=W)
        total_entry = ttk.Entry(label_frame, width=22,textvariable=self.var_total ,font="timesnewroman 12")
        total_entry.grid(row=8, column=1)

        # **************Button Frame*******************
        bill_button = Button(label_frame, text="Bill", font="timesnewroman 12 bold", bg="black",
                             fg="gold",command=self.total, width=8,cursor="hand2")
        bill_button.place(x=0, y=280)

        Save_button = Button(label_frame, text="SAVE",font="timesnewroman 12 bold", command=self.add_data,bg="black",fg="gold", width=8,cursor="hand2")
        Save_button.place(x=0,y=330)
        
        update_button = Button(label_frame, text="UDATE",command=self.update ,font="timesnewroman 12 bold", bg="black",
                             fg="gold", width=8,cursor="hand2")
        update_button.place(x=100, y=330)

        delete_button = Button(label_frame, text="DELETE",command=self.delete, font="timesnewroman 12 bold", bg="black",
                             fg="gold", width=8,cursor="hand2")
        delete_button.place(x=200, y=330)
        
        reset_button = Button(label_frame, text="RESET",command=self.reset ,font="timesnewroman 12 bold", bg="black",
                             fg="gold", width=8,cursor="hand2")
        reset_button.place(x=300, y=330)
        

        # ***************************Label Frame Right****************
        label_frame_r = Frame(self.root, bd=3, relief=SUNKEN)
        label_frame_r.place(x=415, y=41, width=590, height=400)

        right_f = Image.open("bed.png")
        resized_bed = right_f.resize((400, 150), Image.ANTIALIAS)
        self.bed = ImageTk.PhotoImage(resized_bed)
        label_1 = Label(label_frame_r, image=self.bed)
        label_1.place(x=300, y=0, width=300, height=150)




        #**********************Table Frame*************************

        table_frame = Frame(label_frame_r, bd=2, relief=RIDGE)
        table_frame.place(x=0, y=160, width=590, height=210)

        scroll_x = ttk.Scrollbar(table_frame, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_frame, orient=VERTICAL)

        self.table_detail = ttk.Treeview(table_frame, column=(
            "cus", "check_in", "check_out", "room_type", "room_avail", "meal", "no. of day", "paid tax", "total"), xscrollcommand=scroll_x, yscrollcommand=scroll_y)

        scroll_x.pack(side=BOTTOM, fill="x")
        scroll_y.pack(side=RIGHT, fill="y")

        scroll_x.config(command=self.table_detail.xview)
        scroll_y.config(command=self.table_detail.yview)

        self.table_detail.heading("cus", text="Customer contact")
        self.table_detail.heading("check_in", text="Check_In")
        self.table_detail.heading("check_out", text="Check_out")
        self.table_detail.heading("room_type", text="Room Type")
        self.table_detail.heading("room_avail", text="Room Availability")
        self.table_detail.heading("meal", text="Meal")
        self.table_detail.heading("no. of day", text="No. of Days")
        self.table_detail.heading("paid tax", text="Paid tax")
        self.table_detail.heading("total", text="Total")

        self.table_detail["show"] = "headings"
        self.table_detail.column("cus", width=110)
        self.table_detail.column("check_in", width=70)
        self.table_detail.column("check_out", width=70)
        self.table_detail.column("room_type", width=80)
        self.table_detail.column("room_avail", width=100)
        self.table_detail.column("meal", width=80)
        self.table_detail.column("no. of day", width=80)
        self.table_detail.column("paid tax", width=70)
        self.table_detail.column("total", width=70)

        self.table_detail.pack(fill=BOTH, expand=1)
        self.table_detail.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()


    # def add_data(self):
    #     if self.var_contact.get() == "" or self.var_roomavail.get() == "":
    #         messagebox.showerror("Error", "All Requirements are not Filled", parent=self.root)

    #     else:
    #         try:
    #             conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
    #             my_cursor = conn.cursor()
    #             my_cursor.execute("INSERT INTO booking VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
    #                               (self.var_contact.get(),
    #                                self.var_checkin.get(),
    #                                self.var_checkout.get(),
    #                                self.var_roomtype.get(),
    #                                self.var_roomavail.get(),
    #                                self.var_meal.get(),
    #                                self.var_days.get(),
    #                                self.var_tax.get(),
    #                                self.var_total.get(),

    #                                ))
    #             conn.commit()
    #             self.fetch_data()
    #             conn.close()
    #             messagebox.showinfo("success", "Customer has Successfully added.", parent=self.root)
    #         except Exception as es:
    #             messagebox.showwarning("Warning!", f"Something went wrong:{str(es)}", parent=self.root)
    
    #################fetch data from contact#################################
    def fetch_contact(self):
        if self.var_contact.get()=="":
            messagebox.showerror("Error","Fill contact Entry.",parent=self.root)
        else:
            conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
            my_cursor = conn.cursor()
            query=("SELECT cust_name from customer where contact_no=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            
            if row==None:
                messagebox.showerror("ERROR","This number is not found.",parent=self.root)
            else:##########Customer Name################3
                conn.commit()
                conn.close()
                showdataframe=Frame(self.root,bd=4,relief=RAISED,padx=2)
                showdataframe.place(x=420,y=40,width=290,height=165)
                
                lblname=Label(showdataframe,text="Name: ", font="timesnewroman 12 bold")
                lblname.place(x=0,y=0)
                
                name_ans=Label(showdataframe,text=row, font="timesnewroman 12 ")
                name_ans.place(x=90,y=0)
            ##################Gender#######################
            conn = mysql.connector.connect(host="localhost", username="root", password="",database="hotel")
            my_cursor = conn.cursor()
            query=("SELECT gender from customer where contact_no=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row2=my_cursor.fetchone()
            
            gender=Label(showdataframe,text="Gender: ", font="timesnewroman 12 bold")
            gender.place(x=0,y=30)
                
            gender_ans=Label(showdataframe,text=row2, font="timesnewroman 12 ")
            gender_ans.place(x=90,y=30)
            
            ####################Nationality#######################3
            conn = mysql.connector.connect(host="localhost", username="root", password="",database="hotel")
            my_cursor = conn.cursor()
            query=("SELECT Nationality from customer where contact_no=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row3=my_cursor.fetchone()
            
            gender=Label(showdataframe,text="Nationality: ", font="timesnewroman 12 bold")
            gender.place(x=0,y=60)
                
            gender_ans=Label(showdataframe,text=row3, font="timesnewroman 12 ")
            gender_ans.place(x=90,y=60)
            
            #####################Email#############################
            conn = mysql.connector.connect(host="localhost", username="root", password="",database="hotel")
            my_cursor = conn.cursor()
            query=("SELECT email from customer where contact_no=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row4=my_cursor.fetchone()
            
            email=Label(showdataframe,text="Email: ", font="timesnewroman 12 bold")
            email.place(x=0,y=90)
                
            email_ans=Label(showdataframe,text=row4, font="timesnewroman 12 ")
            email_ans.place(x=90,y=90)
            
            ##########################Address###########################
            conn = mysql.connector.connect(host="localhost", username="root", password="",database="hotel")
            my_cursor = conn.cursor()
            query=("SELECT address from customer where contact_no=%s")
            value=(self.var_contact.get(),)
            my_cursor.execute(query,value)
            row5=my_cursor.fetchone()
            
            address=Label(showdataframe,text="Address: ", font="timesnewroman 12 bold")
            address.place(x=0,y=120)
                
            address_ans=Label(showdataframe,text=row5, font="timesnewroman 12 ")
            address_ans.place(x=90,y=120)
    
    def add_data(self):
        if self.var_contact.get() == "" or self.var_checkin.get() == "" or self.var_checkout.get() == "":
            messagebox.showerror("Error", "All Requirements are not Filled", parent=self.root)

        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("INSERT INTO book VALUES (%s,%s,%s,%s,%s,%s,%s)",
                                  (self.var_contact.get(),
                                    self.var_checkin.get(),
                                    self.var_checkout.get(),
                                    self.var_roomtype.get(),
                                    self.var_roomavail.get(),
                                    self.var_meal.get(),
                                    self.var_no_days.get()
                                   ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("success", "Room Booked", parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
                
    def fetch_data(self):
        conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT * FROM book")
        rows=my_cursor.fetchall()
        if len(rows) !=0:
            self.table_detail.delete(*self.table_detail.get_children())
            for i in rows:
                self.table_detail.insert("",END,values=i)
            conn.commit()
        conn.close()       
        
    def get_cursor(self,event=""):
        cursor_row=self.table_detail.focus()
        content=self.table_detail.item(cursor_row)
        row=content["values"]

        self.var_contact.set(row[0])
        self.var_checkin.set(row[1])
        self.var_checkout.set(row[2])
        self.var_roomtype.set(row[3])
        self.var_roomavail.set(row[4])
        self.var_meal.set(row[5])
        self.var_no_days.set(row[6])     
    def update(self):
        if self.var_contact.get()=="":
            messagebox.showerror("ERROR","Please Enter Mobile Number",parent=self.root)
        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("UPDATE book SET check_in=%s,check_out=%s,room_type=%s, room_available=%s,"
                                " meal=%s,no_of_days=%s"
                                "WHERE contact=%s",(
                                    self.var_checkin.get(),
                                    self.var_checkout.get(),
                                    self.var_roomtype.get(),
                                    self.var_roomavail.get(),
                                    self.var_meal.get(),
                                    self.var_no_days.get(),
                                    self.var_contact.get()
                                                            ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("UPDATED","Room Details Updated Successfully.",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
   
    ##########################Delete Function################################
    def delete(self):
        mdelete=messagebox.askokcancel("Hotel Management System", "Do you really want to delete this.", parent=self.root)
        try:
            if mdelete>0:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                query ="delete from book where contact=%s"
                values = (self.var_contact.get(),)
                my_cursor.execute(query,values)
                messagebox.showinfo("Success","Successfully Deleted.")
                # my_cursor.execute("delete from customer where cust_ref=%s",(self.var_ref))

            else:
                if not self.delete:
                    return

            conn.commit()
            self.fetch_data()
            conn.close()
        except Exception as es:
            messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
       
    def reset(self):
        self.var_contact.set("")
        self.var_checkin.set("")
        self.var_checkout.set("")
        # self.var_roomtype.set("")
        self.var_roomavail.set("")
        # self.var_meal.set("")
        self.var_no_days.set("")
        self.var_total.set("")
        self.var_tax.set("")
        
    def total(self):
        inDate=self.var_checkin.get()
        outDate=self.var_checkout.get()
        
        inDate=datetime.strptime(inDate,"%d/%m/%Y")
        outDate=datetime.strptime(outDate,"%d/%m/%Y")
        self.var_no_days.set(abs(outDate-inDate).days)
        
        if(self.var_meal.get()=="Breakfast" and self.var_roomtype.get()=="Single Room"):
            q1=700
            q2=1100
            q3=float(self.var_no_days.get())
            q4=float(q3*q2)
            q5=float(q1+q4)
            tax="Rs."+str("%.2f"%((q5)*0.05))
            b_total="Rs."+str("%.2f"%(q5+((q5)*0.05)))
            self.var_tax.set(tax)
            self.var_total.set(b_total)
        elif(self.var_meal.get()=="Lunch" or "Dinner" and self.var_roomtype.get()=="Single Room"):
            q1=1000
            q2=1100
            q3=float(self.var_no_days.get())
            q4=float(q3*q2)
            q5=float(q1+q4)
            tax="Rs."+str("%.2f"%((q5)*0.05))
            b_total="Rs."+str("%.2f"%(q5+((q5)*0.05)))
            self.var_tax.set(tax)
            self.var_total.set(b_total)
        elif(self.var_meal.get()=="Lunch" or "Dinner" and self.var_roomtype.get()=="Double Room"):
            q1=1000
            q2=1700
            q3=float(self.var_no_days.get())
            q4=float(q3*q2)
            q5=float(q1+q4)
            tax="Rs."+str("%.2f"%((q5)*0.05))
            b_total="Rs."+str("%.2f"%(q5+((q5)*0.05)))
            self.var_tax.set(tax)
            self.var_total.set(b_total)
        elif(self.var_meal.get()=="Breakfast" and self.var_roomtype.get()=="Double Room"):
            q1=700
            q2=1700
            q3=float(self.var_no_days.get())
            q4=float(q3*q2)
            q5=float(q1+q4)
            tax="Rs."+str("%.2f"%((q5)*0.05))
            b_total="Rs."+str("%.2f"%(q5+((q5)*0.05)))
            self.var_tax.set(tax)
            self.var_total.set(b_total)
        elif(self.var_meal.get()=="Lunch" or "Dinner" or"Breakfast" and self.var_roomtype.get()=="Double Room"):
            q1=1400
            q2=2200
            q3=float(self.var_no_days.get())
            q4=float(q3*q2)
            q5=float(q1+q4)
            tax="Rs."+str("%.2f"%((q5)*0.05))
            b_total="Rs."+str("%.2f"%(q5+((q5)*0.05)))
            self.var_tax.set(tax)
            self.var_total.set(b_total)
        
            
            
            
            
        
        
           
                
        
                 





if __name__ == '__main__':
    root=Tk()
    obj=book_det(root)
    root.mainloop()