import string
from tkinter import *
from PIL import Image, ImageTk
from tkinter import ttk
import random
from tkinter import messagebox
from matplotlib.pyplot import text
import mysql.connector


class detail:
    def __init__(self, root):
        self.root = root
        self.root.title("Customer")
        self.root.geometry("1030x465+248+178")
        
##################Varibales#####################
        self.var_floor=StringVar()
        self.var_roomno=StringVar()
        self.var_roomtype=StringVar()
        self.var_price=StringVar()
        
 # *****************Title*******************
        title = Label(self.root, text="ROOM DETAILS", bg="black", fg="Gold", font="timesnewroman 18  bold")
        title.place(x=0, y=0, width=1020, height=40)
        
# *****************logo*******************
        logo = Image.open("logo.png")
        resized_logo = logo.resize((160, 40), Image.ANTIALIAS)
        self.logo1 = ImageTk.PhotoImage(resized_logo)
        label_1 = Label(root, image=self.logo1)
        label_1.place(x=0, y=0, width=160, height=40)
#*****************label frame*********************
        label_frame=LabelFrame(self.root,text="New Room Add",bd=3,relief=SUNKEN,font="timesnewroman 14  bold",cursor="hand2")
        label_frame.place(x=10,y=41,width=480,height=350)
        
######################Image inside label frame####################3
        bed = Image.open("bed.png")
        resized_bd = bed.resize((479, 160), Image.ANTIALIAS)
        self.bd = ImageTk.PhotoImage(resized_bd)
        label_1 = Label(label_frame, image=self.bd)
        label_1.place(x=5, y=0, width=470, height=160)
        
#*************************Label and entries#########################
        #floor
        floor=Label(label_frame,text="Floor",fg="black",font="timesnewroman 12 bold",padx=2,pady=4)
        floor.place(x=5,y=170)
        floor_entry=ttk.Entry(label_frame,width=22,textvariable=self.var_floor,font="timesnewroman 12")
        floor_entry.place(x=100,y=172)
        
        #Room No
        room_no=Label(label_frame,text="Room No",fg="black",font="timesnewroman 12 bold",padx=2,pady=4)
        room_no.place(x=5,y=210)
        room_no_entry=ttk.Entry(label_frame,width=22,textvariable=self.var_roomno,font="timesnewroman 12")
        room_no_entry.place(x=100,y=212)
        
        #Room Type
        room_type=Label(label_frame,text="Room Type",fg="black",font="timesnewroman 12 bold",padx=2,pady=4)
        room_type.place(x=5,y=250)
        roomtype_combo = ttk.Combobox(label_frame, text="SELECT",textvariable=self.var_roomtype,font="timesnewroman 12",
                                         width=20, state='readonly')
        roomtype_combo["values"] = ("Single Room", "Double Room", "Triple Room")
        roomtype_combo.current(0)
        roomtype_combo.place(x=100,y=252)
        
        #Room No
        price=Label(label_frame,text="Price",fg="black",font="timesnewroman 12 bold",padx=2,pady=4)
        price.place(x=5,y=290)
        price_entry=ttk.Entry(label_frame,width=22,textvariable=self.var_price,font="timesnewroman 12")
        price_entry.place(x=100,y=292)
        
        ######################Button Frame####################
        frame1 = Frame(label_frame, bd=3, relief=SUNKEN)
        frame1.place(x=335, y=182, width=110, height=120)
        
        #######################buttons########################
        add_button = Button(frame1, text='Add',command=self.add_data ,font="timesnewroman 10 bold", fg="gold", bg="black", width=12,
                             cursor="hand2", bd=3)
        add_button.grid(row=0, column=0)
        
        update_button = Button(frame1, text='Update',command=self.update, font="timesnewroman 10 bold", fg="gold", bg="black", width=12,
                             cursor="hand2", bd=3)
        update_button.grid(row=1, column=0)
        
        delete_button = Button(frame1, text='Delete',command=self.delete, font="timesnewroman 10 bold", fg="gold", bg="black", width=12,
                             cursor="hand2", bd=3)
        delete_button.grid(row=2, column=0)
        
        reset_button = Button(frame1, text='Reset',command=self.reset ,font="timesnewroman 10 bold", fg="gold", bg="black", width=12,
                             cursor="hand2", bd=3)
        reset_button.grid(row=3, column=0)
        
    #############Label frame right###################
        table_detail=LabelFrame(self.root,text="Show Room Details",bd=3,relief=SUNKEN,font="timesnewroman 14  bold",cursor="hand2")
        table_detail.place(x=490,y=41,width=500,height=350)
        scroll_x = ttk.Scrollbar(table_detail, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_detail, orient=VERTICAL)
        scroll_x.pack(side=BOTTOM, fill="x")
        scroll_y.pack(side=RIGHT, fill="y")
        
        self.table_detail = ttk.Treeview(table_detail, column=(
            "floor", "roomno", "roomtype", "price"), xscrollcommand=scroll_x, yscrollcommand=scroll_y)


        scroll_x.config(command=self.table_detail.xview)
        scroll_y.config(command=self.table_detail.yview)
        
        self.table_detail.heading("floor", text="Floor")
        self.table_detail.heading("roomno", text="Room No")
        self.table_detail.heading("roomtype", text="Room Type")
        self.table_detail.heading("price", text="Price")

        self.table_detail["show"] = "headings"
        self.table_detail.column("floor", width=110)
        self.table_detail.column("roomno", width=70)
        self.table_detail.column("roomtype", width=70)
        self.table_detail.column("price", width=80)
        self.table_detail.pack(fill=BOTH, expand=1)
        self.table_detail.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()
        
    def add_data(self):
        if self.var_roomno.get() == "" or self.var_floor.get() == "" or self.var_price.get() == "":
            messagebox.showerror("Error", "All Requirements are not Filled", parent=self.root)

        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("INSERT INTO room_details VALUES (%s,%s,%s,%s)",
                                  (self.var_floor.get(),
                                    self.var_roomno.get(),
                                    self.var_roomtype.get(),
                                    self.var_price.get(),
                                   ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("success", "Sucessfully Room Inserted.", parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
    
    def fetch_data(self):
        conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT * FROM room_details")
        rows=my_cursor.fetchall()
        if len(rows) !=0:
            self.table_detail.delete(*self.table_detail.get_children())
            for i in rows:
                self.table_detail.insert("",END,values=i)
            conn.commit()
        conn.close()     
    def get_cursor(self,event=""):
        cursor_row=self.table_detail.focus()
        content=self.table_detail.item(cursor_row)
        row=content["values"]

        self.var_floor.set(row[0])
        self.var_roomno.set(row[1])
        self.var_roomtype.set(row[2])
        self.var_price.set(row[3])
        
    def update(self):
        if self.var_roomno.get()=="":
            messagebox.showerror("ERROR","Please Enter Mobile Number",parent=self.root)
        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("UPDATE room_details SET floor=%s,room_type=%s, price=%s"
                                "WHERE room_no=%s",(
                                    self.var_floor.get(),
                                    self.var_roomtype.get(),
                                    self.var_price.get(),
                                    self.var_roomno.get()
                                                            ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("UPDATED","Room Details Updated Successfully.",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
        
    def delete(self):
        mdelete=messagebox.askokcancel("Hotel Management System", "Do you really want to delete this.", parent=self.root)
        try:
            if mdelete>0:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                query ="delete from room_details where room_no=%s"
                values = (self.var_roomno.get(),)
                my_cursor.execute(query,values)
                messagebox.showinfo("Success","Successfully Deleted.")
                # my_cursor.execute("delete from customer where cust_ref=%s",(self.var_ref))

            else:
                if not self.delete:
                    return

            conn.commit()
            self.fetch_data()
            conn.close()
        except Exception as es:
            messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)

        
    def reset(self):
        self.var_floor.set("")
        self.var_roomno.set("")
        #self.var_roomtype.set("")
        self.var_price.set("")
        
        
        
        
        
        
if __name__ == '__main__':
    root=Tk()
    obj=detail(root)
    root.mainloop()