from tkinter import *
from PIL import Image, ImageTk
from tkinter import ttk
import random
from tkinter import messagebox
import mysql.connector


class cust_win:
    def __init__(self, root):
        self.root = root
        self.root.title("Customer")
        self.root.geometry("1030x465+248+178")

        # ******************Title******************

        title = Label(self.root, text="Add Customer Details", bg="black", fg="Gold", font="timesnewroman 18  bold")
        title.place(x=0, y=0, width=1020, height=40)

        # *****************Random*****************

        self.var_ref = StringVar()
        x = random.randint(1000, 99999)
        self.var_ref.set(str(x))

        self.var_name = StringVar()
        self.var_Father_name = StringVar()
        self.var_gender = StringVar()
        self.var_Cnic = StringVar()
        self.var_Postal = StringVar()
        self.var_contact = StringVar()
        self.var_nationality = StringVar()
        self.var_email = StringVar()
        self.var_Id = StringVar()
        self.var_address = StringVar()
        self.var_search=StringVar()
        self.var_search_entry=StringVar()

        # *****************logo*******************

        logo = Image.open("logo.png")
        resized_logo = logo.resize((160, 40), Image.ANTIALIAS)
        self.logo1 = ImageTk.PhotoImage(resized_logo)

        label_1 = Label(root, image=self.logo1)
        label_1.place(x=0, y=0, width=160, height=40)

        # *****************Label_frame*******************

        label_frame = LabelFrame(self.root, text="Customer Details", bd=3, relief=SUNKEN, font="timesnewroman 14  bold")
        label_frame.place(x=10, y=41, width=400, height=400)

        # *****************Label & Entries*******************
        # reference
        cust_ref = Label(label_frame, text="Customer Reference", font="timesnewroman 12", padx=2, pady=4)
        cust_ref.grid(row=0, column=0, sticky=W)
        ref_entry = ttk.Entry(label_frame, textvariable=self.var_ref, width=24, font="timesnewroman 12",
                              state="disabled")
        ref_entry.grid(row=0, column=1)
        # Name
        cust_Name = Label(label_frame, text="Customer Name", font="timesnewroman 12", padx=2, pady=4)
        cust_Name.grid(row=1, column=0, sticky=W)
        Name_entry = ttk.Entry(label_frame, width=24, textvariable=self.var_name, font="timesnewroman 12")
        Name_entry.grid(row=1, column=1)

        # Father Name
        f_Name = Label(label_frame, text="Father Name", font="timesnewroman 12", padx=2, pady=4)
        f_Name.grid(row=2, column=0, sticky=W)
        f_Name_entry = ttk.Entry(label_frame, textvariable=self.var_Father_name, width=24, font="timesnewroman 12")
        f_Name_entry.grid(row=2, column=1)

        # Gender
        gender_label = Label(label_frame, text="Gender", font="timesnewroman 12", padx=2, pady=4)
        gender_label.grid(row=3, column=0, sticky=W)
        gender_combo = ttk.Combobox(label_frame, textvariable=self.var_gender, font="timesnewroman 12",
                                    width=22, state='readonly')
        gender_combo["values"] = ("Male", "Female", "Other")
        gender_combo.current(0)
        gender_combo.grid(row=3, column=1)
        # CNIC
        cnic_label = Label(label_frame, text="CNIC", font="timesnewroman 12", padx=2, pady=4)
        cnic_label.grid(row=4, column=0, sticky=W)
        cnic_entry = ttk.Entry(label_frame, width=24, textvariable=self.var_Cnic, font="timesnewroman 12")
        cnic_entry.grid(row=4, column=1)

        # postcode
        code_label = Label(label_frame, text="Postal code", font="timesnewroman 12", padx=2, pady=4)
        code_label.grid(row=5, column=0, sticky=W)
        code_entry = ttk.Entry(label_frame, textvariable=self.var_Postal, width=24, font="timesnewroman 12")
        code_entry.grid(row=5, column=1)

        # contact No
        no_label = Label(label_frame, text="Contact No.", font="timesnewroman 12", padx=2, pady=4)
        no_label.grid(row=6, column=0, sticky=W)
        no_entry = ttk.Entry(label_frame, textvariable=self.var_contact, width=24, font="timesnewroman 12")
        no_entry.grid(row=6, column=1)

        # Nationality
        Nat_label = Label(label_frame, text="Nationality: ", font="timesnewroman 12", padx=2, pady=4)
        Nat_label.grid(row=7, column=0, sticky=W)
        nationality_combo = ttk.Combobox(label_frame, text="SELECT" ,textvariable=self.var_nationality, font="timesnewroman 12",
                                         width=22, state='readonly')
        nationality_combo["values"] = ("Pakistani", "Indian", "American", "British")
        nationality_combo.current(0)
        nationality_combo.grid(row=7, column=1)

        # email
        Email_label = Label(label_frame, text="Email", font="timesnewroman 12", padx=2, pady=4)
        Email_label.grid(row=8, column=0, sticky=W)
        Email_entry = ttk.Entry(label_frame, textvariable=self.var_email, width=24, font="timesnewroman 12")
        Email_entry.grid(row=8, column=1)

        # idnumber
        id_label = Label(label_frame, text="ID No.", font="timesnewroman 12", padx=2, pady=4)
        id_label.grid(row=9, column=0, sticky=W)
        id_entry = ttk.Entry(label_frame, width=24, textvariable=self.var_Id, font="timesnewroman 12")
        id_entry.grid(row=9, column=1)

        # Address
        adress_label = Label(label_frame, text="Address", font="timesnewroman 12", padx=2, pady=4)
        adress_label.grid(row=10, column=0, sticky=W)
        adress_entry = ttk.Entry(label_frame, textvariable=self.var_address, width=24, font="timesnewroman 12")
        adress_entry.grid(row=10, column=1)

        # **************Button Frame*******************
        add_button = Button(label_frame, text="ADD", command=self.add_data,bd=0, font="timesnewroman 12 bold", bg="black",
                            fg="gold", width=6,cursor="hand2")
        add_button.place(x=20,y=340)
        
        delete_button = Button(label_frame, text="Delete", command=self.delete,bd=0, font="timesnewroman 12 bold", bg="black",
                            fg="gold", width=6,cursor="hand2")
        delete_button.place(x=110,y=340)
        
        update_button = Button(label_frame, text="Update", command=self.update,bd=0, font="timesnewroman 12 bold", bg="black",
                            fg="gold", width=6,cursor="hand2")
        update_button.place(x=200,y=340)
  
        reset_button = Button(label_frame, text="RESET",command=self.reset ,bd=0,font="timesnewroman 12 bold", bg="black", fg="gold", width=6,cursor="hand2")
        reset_button.place(x=290,y=340)
        
        

        # ***************************Label Frame Right****************
        label_frame_r = LabelFrame(self.root, text="View Detail and Search System", bd=3, relief=SUNKEN,
                                   font="timesnewroman 14  bold")
        label_frame_r.place(x=415, y=41, width=590, height=400)
        
        #***********************Search Bar***************************
        searchlbl=Label(label_frame_r,text="Search by", fg="white",bg="black",font="timesnewroman 14 bold")
        searchlbl.place(x=5,y=5)
        
        search_combo = ttk.Combobox(label_frame_r, textvariable=self.var_search, font="timesnewroman 12",
                                    width=18, state='readonly')
        search_combo["values"] = ("Contact", "Reference No", "ID")
        search_combo.current(0)
        search_combo.place(x=115,y=5)
        
        search_entry = ttk.Entry(label_frame_r, width=18, textvariable=self.var_search_entry, font="timesnewroman 12")
        search_entry.place(x=310,y=5)
        
        search_button = Button(label_frame_r, text="Search", command=self.search,bd=0,font="timesnewroman 12 bold", bg="black", fg="gold", width=8,cursor="hand2")
        search_button.place(x=490,y=0)
        
        showall_button = Button(label_frame_r, text="Show All" ,bd=0,font="timesnewroman 12 bold", bg="black", fg="gold",command=self.fetch_data, width=28,cursor="hand2")
        showall_button.place(x=150,y=40)
        
        




        # ***********Detail Frame*******************
        detail_frame = Frame(label_frame_r, bd=3, relief=SUNKEN)
        detail_frame.place(x=0, y=140, width=580, height=300)

        # ******************Table Frame**********************

        table_frame = Frame(label_frame_r, bd=2, relief=RIDGE)
        table_frame.place(x=0, y=75, width=580, height=300)

        scroll_x = ttk.Scrollbar(table_frame, orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_frame, orient=VERTICAL)

        self.table_detail = ttk.Treeview(table_frame, column=(
        "ref", "Name", "Father_name", "gender", "Cnic", "Postal code", "contact","Nationality", "Email", "Id no.",
        "address"), xscrollcommand=scroll_x, yscrollcommand=scroll_y)

        scroll_x.pack(side=BOTTOM, fill="x")
        scroll_y.pack(side=RIGHT, fill="y")

        scroll_x.config(command=self.table_detail.xview)
        scroll_y.config(command=self.table_detail.yview)

        self.table_detail.heading("ref", text="Customer Reference")
        self.table_detail.heading("Name", text="Customer Name")
        self.table_detail.heading("Father_name", text="Father Name")
        self.table_detail.heading("gender", text="Gender")
        self.table_detail.heading("Cnic", text="CNIC")
        self.table_detail.heading("Postal code", text="Postal Code")
        self.table_detail.heading("contact", text="Contact Number")
        self.table_detail.heading("Nationality", text="Nationality")
        self.table_detail.heading("Email", text="Email")
        self.table_detail.heading("Id no.", text="ID No.")
        self.table_detail.heading("address", text="Address")

        self.table_detail["show"] = "headings"

        self.table_detail.column("ref", width=110)
        self.table_detail.column("Name", width=100)
        self.table_detail.column("Father_name", width=100)
        self.table_detail.column("gender", width=80)
        self.table_detail.column("Cnic", width=100)
        self.table_detail.column("Postal code", width=100)
        self.table_detail.column("Nationality", width=100)
        self.table_detail.column("contact", width=100)
        self.table_detail.column("Email", width=100)
        self.table_detail.column("Id no.", width=70)
        self.table_detail.column("address", width=100)

        self.table_detail.pack(fill=BOTH, expand=1)
        self.table_detail.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()

    def add_data(self):
        if self.var_name.get() == "" or self.var_Cnic.get() == "" or self.var_contact.get() == "":
            messagebox.showerror("Error", "All Requirements are not Filled", parent=self.root)

        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("INSERT INTO customer VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                                  (self.var_ref.get(),
                                   self.var_name.get(),
                                   self.var_Father_name.get(),
                                   self.var_gender.get(), 
                                   self.var_Cnic.get(),
                                   self.var_Postal.get(),
                                   self.var_contact.get(),
                                   self.var_nationality.get(),
                                   self.var_email.get(),
                                   self.var_Id.get(),
                                   self.var_address.get()
                                   ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("success", "Customer has Successfully added.", parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)

    def fetch_data(self):
        conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("SELECT * FROM customer")
        rows=my_cursor.fetchall()
        if len(rows) !=0:
            self.table_detail.delete(*self.table_detail.get_children())
            for i in rows:
                self.table_detail.insert("",END,values=i)
            conn.commit()
        conn.close()

    def get_cursor(self,event=""):
        cursor_row=self.table_detail.focus()
        content=self.table_detail.item(cursor_row)
        row=content["values"]

        self.var_ref.set(row[0]),
        self.var_name.set(row[1]),
        self.var_Father_name.set(row[2]),
        self.var_gender.set(row[3]),
        self.var_Cnic.set(row[4]),
        self.var_Postal.set(row[5]),
        self.var_contact.set(row[6]),
        self.var_nationality.set(row[7]),
        self.var_email.set(row[8]),
        self.var_Id.set(row[9]),
        self.var_address.set(row[10])

    def update(self):
        if self.var_contact.get()=="":
            messagebox.showerror("ERROR","Please Enter Mobile Number",parent=self.root)
        else:
            try:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("UPDATE customer SET cust_name=%s,father_name=%s,gender=%s,cnic=%s, postal_code=%s,"
                                " contact_no=%s,Nationality=%s,email=%s, id_no=%s, address=%s"
                                "WHERE cust_ref=%s",(

                                                            self.var_name.get(),
                                                            self.var_Father_name.get(),
                                                            self.var_gender.get(),
                                                            self.var_Cnic.get(),
                                                            self.var_Postal.get(),
                                                            self.var_contact.get(),
                                                            self.var_nationality.get(),
                                                            self.var_email.get(),
                                                            self.var_Id.get(),
                                                            self.var_address.get(),
                                                            self.var_ref.get()
                                                            ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("UPDATED","Customer Updated Successfully.",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
            

    def delete(self):
        mdelete=messagebox.askokcancel("Hotel Management System", "Do you really want to delete this.", parent=self.root)
        try:
            if mdelete>0:
                conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
                my_cursor = conn.cursor()
                query ="delete from customer where cust_ref=%s"
                values = (self.var_ref.get(),)
                my_cursor.execute(query,values)
                messagebox.showinfo("Success","Successfully Deleted.")
                # my_cursor.execute("delete from customer where cust_ref=%s",(self.var_ref))

            else:
                if not self.delete:
                    return

            conn.commit()
            self.fetch_data()
            conn.close()
        except Exception as es:
            messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)

    def reset(self):
        # self.var_ref.set(""),
        self.var_name.set(""),
        self.var_Father_name.set(""),
        # self.var_gender.set(""),
        self.var_Cnic.set(""),
        self.var_Postal.set(""),
        self.var_contact.set(""),
        # self.var_nationality.set(""),
        self.var_email.set(""),
        self.var_Id.set(""),
        self.var_address.set("")
        x = random.randint(1000, 99999)
        self.var_ref.set(str(x))
        
    def search(self):
        
        try:
            conn = mysql.connector.connect(host="localhost", username="root", password="", database="hotel")
            my_cursor = conn.cursor()
            
            my_cursor.execute("select * from customer where"+str(self.var_search.get())+" LIKE '%"+str(self.var_search_entry.get())+"%'")
            row=my_cursor.fetchall()
            if len(row)!=0:
                self.table_detail.delete(*self.table_detail.get_children())
                for i in row:
                    self.table_detail.insert("",END,values=i)
                conn.Commit()
            conn.close()
        except Exception as es:
            messagebox.showwarning("Warning!",f"Something went wrong:{str(es)}",parent=self.root)
                
            

























if __name__ == '__main__':
    root = Tk()
    obj = cust_win(root)
    root.mainloop()
