from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from front import HotelManagement

class login_window:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1300x700")
        self.root.title("LOGIN PAGE")
        self.root.minsize(1300, 680)
        self.root.maxsize(1300,680)
        

        #=======================Heading=====================================
        frame1=Frame(self.root,width=1300,height=60,bd=6,relief=SUNKEN, bg="black")
        frame1.place(x=0,y=0)
        head=Label(frame1,text="Hotel Management System",bg="black",fg="Gold", font="timesnewroman 24 bold")
        head.place(x=450,y=0)


        #=======================Backround Image==============================

        img1=Image.open("log.jpg")
        rz=img1.resize((1280,650),Image.ANTIALIAS)
        self.bg=ImageTk.PhotoImage(rz)
        label_img1=Label(image=self.bg)
        label_img1.place(x=0,y=50,relwidth=1,relheight=1)

        #=============================Frame=====================================
        mid_frame=Frame(self.root,bg="black",bd=4,relief=SUNKEN)
        mid_frame.place(x=500,y=150,width=300,height=400)

        #=========================profile Logo===================================
        img2 = Image.open("profile.png")
        rz2 = img2.resize((50, 50), Image.ANTIALIAS)
        self.profile = ImageTk.PhotoImage(rz2)
        label_img1 = Label(mid_frame,image=self.profile)
        label_img1.place(x=125, y=0)

        get_label=Label(mid_frame,text="Get Started",bg="black",fg="white", font="timesnewroman 20 bold")
        get_label.place(x=80,y=55)

        userpic = Image.open("user.png")
        rz3 = userpic.resize((30, 30), Image.ANTIALIAS)
        self.userpic = ImageTk.PhotoImage(rz3)
        user_pic = Label(mid_frame, image=self.userpic)
        user_pic.place(x=30, y=92, height=22,width=20)

        username = Label(mid_frame, text="Username", bg="black", fg="white", font="timesnewroman 12 bold")
        username.place(x=55, y=95)
        self.user_entry=ttk.Entry(mid_frame ,font="timesnewroman 12 bold",width=25)
        self.user_entry.place(x=30,y=125)

        passpic = Image.open("key.png")
        rz4 = passpic.resize((20, 20), Image.ANTIALIAS)
        self.paspic = ImageTk.PhotoImage(rz4)
        pass_pic = Label(mid_frame, image=self.paspic)
        pass_pic.place(x=30, y=160, height=20, width=20)
        password=Label(mid_frame, text="Password", bg="black", fg="white", font="timesnewroman 12 bold")
        password.place(x=50, y=155)
        self.Pas_entry =ttk.Entry(mid_frame,font="timesnewroman 12 bold", width=25)
        self.Pas_entry.place(x=30, y=185)

        #*************loginbutton****************

        login_button=Button(mid_frame,bg="blue",bd=5,fg="white",relief=RIDGE,text="Login",command=self.login,cursor="hand2",font="timesnewroman 12 bold", width=10,activeforeground="white",activebackground="blue")
        login_button.place(x=90,y=235)



    def login(self):
        if self.user_entry.get()=="" or self.Pas_entry=="":
            messagebox.showerror("ERROR!","You have to fill all required entries.")

        elif self.user_entry.get()=="Subtain" and self.Pas_entry.get()=="kotli123" or \
                self.user_entry.get()=="Waleed" and self.Pas_entry.get()=="waleed":
            messagebox.showinfo("Sucess","*****Welcome to Hotel Management System******")
            self.new_window=Toplevel(self.root)
            self.app=HotelManagement(self.new_window)


        else:
            messagebox.showerror("Invalid!","Please enter Valid Username and Password.")
            self.Pas_entry.clear()














if __name__ == '__main__':
    root=Tk()
    obj=login_window(root)
    root.mainloop()