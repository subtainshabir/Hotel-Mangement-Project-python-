from tkinter import*
from PIL import Image, ImageTk
from tkinter import messagebox
from Customer import cust_win
from booking import book_det
from details import detail

class HotelManagement:
    def __init__(self, root):
        self.root=root
        self.root.title("Hotel Management")
        self.root.geometry("1300x720")
        self.root.maxsize(1300,720)
        self.root.minsize(1300,720)

        # *****************logo*******************

        logo = Image.open("logo.png")
        resized_logo = logo.resize((240, 100), Image.ANTIALIAS)
        self.logo1 = ImageTk.PhotoImage(resized_logo)

        label_1 = Label(root, image=self.logo1)
        label_1.place(x=0, y=5, width=240, height=100)

        #********************Title Image*****************

        img1 = Image.open("top.png")
        resized_image = img1.resize((1050, 100), Image.ANTIALIAS)
        self.photo= ImageTk.PhotoImage(resized_image)
        label_1 = Label(self.root, image=self.photo)
        label_1.place(x=250, y=5, width=1050, height=100)

        # ******************Title******************

        title = Label(self.root, text="Hotel Management System", bg="black", fg="Gold", font="timesnewroman 24 bold")
        title.place(x=0, y=110, width=1300)

        # *****************Main Frame**************

        main_frame = Frame(self.root, bd=6, relief=SUNKEN)
        main_frame.place(x=0, y=150, width=1300, height=620)

        # ****************MENU FRAME**************

        menu_frame = Frame(main_frame, bd=5, relief=SUNKEN)
        menu_frame.place(x=0, y=40, width=238, height=180)

        # ****************MENU********************

        label_menu = Label(main_frame, text='MENU', bg="black", fg="Gold", font="timesnewroman 18 bold")
        label_menu.place(x=0, y=5, width=240)

        # ***************BUTTONS*****************

        cust_button = Button(menu_frame, text='CUSTOMER',command=self.cust_details, font="timesnewroman 14 bold", fg="gold", bg="black", width=19,
                             cursor="hand2", bd=3, )
        cust_button.grid(row=0, column=0)

        room_button = Button(menu_frame, text='BOOKINGS',font="timesnewroman 14 bold",command=self.booking_detail, fg="gold", bg="black", width=19,
                             cursor="hand2", bd=3)
        room_button.grid(row=1, column=0)
        
        room_button = Button(menu_frame, text='ROOM DETAILS',command=self.room_detail,font="timesnewroman 14 bold", fg="gold", bg="black", width=19,
                             cursor="hand2", bd=3)
        room_button.grid(row=2, column=0)

        logout_button = Button(menu_frame, text='LOG OUT',command=self.logout, font="timesnewroman 14 bold", fg="gold", bg="black",
                               width=19, cursor="hand2", bd=3)
        logout_button.grid(row=3, column=0)

        # **************Right Image**************
        img2 = Image.open("front.jpg")
        resized_image2 = img2.resize((1030, 495), Image.ANTIALIAS)
        self.photo2 = ImageTk.PhotoImage(resized_image2)

        label_2 = Label(main_frame, image=self.photo2)
        label_2.place(x=250, y=0, width=1030, height=495)

        # ************Down Images***************
        img3 = Image.open("coffee.png")
        resized_image3 = img3.resize((233, 180), Image.ANTIALIAS)
        self.photo3 = ImageTk.PhotoImage(resized_image3)
        label_3 = Label(main_frame, image=self.photo3)
        label_3.place(x=5, y=220, width=233, height=160)

        img4 = Image.open("food.png")
        resized_image4 = img4.resize((233, 100), Image.ANTIALIAS)
        self.photo4 = ImageTk.PhotoImage(resized_image4)
        label_3 = Label(main_frame, image=self.photo4)
        label_3.place(x=5,y=390, width=233, height=110)



    def cust_details(self):
        self.new_window=Toplevel(self.root)
        self.app=cust_win(self.new_window)

    def booking_detail(self):
        self.nwindow=Toplevel(self.root)
        self.app=book_det(self.nwindow)
    
    def room_detail(self):
        self.nwindow=Toplevel(self.root)
        self.app=detail(self.nwindow)

    def logout(self):
        self.root.destroy()
        messagebox.showinfo("Hotel Management System","You have successfully logged out")
        
        










if __name__ == '__main__':
    root=Tk()
    obj=HotelManagement(root)
    root.mainloop()
